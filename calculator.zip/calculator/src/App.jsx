import React from 'react';
import Calculator from './Components/calculator';

const App = () => {
  return (
    <div>
      <Calculator />
    </div>
  );
};

export default App;