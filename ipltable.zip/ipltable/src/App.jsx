import React from 'react';
import './App.css';
import IplPointsTable from './components/IplPointsTable';

function App() {
  return (
    <div className="App">
      <IplPointsTable />
    </div>
  );
}

export default App;
